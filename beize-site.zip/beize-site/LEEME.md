# Cómo activar el pago con tarjeta (crédito y débito)

El dinero llega a tu cuenta de **Mercado Pago** y de ahí lo retiras a tu cuenta bancaria.

## 1. Crea tu cuenta y copia la clave
1. Crea una cuenta en mercadopago.cl y verifica tu identidad.
2. Entra a mercadopago.cl/developers → Tus integraciones → Crear aplicación (Checkout Pro).
3. Copia el **Access Token de producción** (empieza con `APP_USR-`). No lo compartas ni lo pegues en el HTML.

## 2. Sube el sitio (necesita un hosting con funciones, ej. Netlify)
1. Sube esta carpeta completa (index.html + carpeta netlify) a un repositorio de GitHub y conéctalo a Netlify
   (o usa Netlify CLI: `netlify deploy --prod`).
2. En Netlify: Site settings → Environment variables → agrega
   - `MP_ACCESS_TOKEN` = tu Access Token
   - `SITE_URL` = la dirección de tu sitio, ej. https://beizeagency.cl
3. Vuelve a desplegar.

## 3. Prueba
Primero usa el token de **pruebas** con tarjetas de prueba de Mercado Pago; luego cambia al de producción.

## Notas
- Los precios se cobran desde `netlify/functions/checkout.js` (lista `CATALOG`). Si cambias un precio o agregas un
  producto en el HTML, actualiza también esa lista.
- La página nunca toca datos de tarjeta: el pago ocurre en Mercado Pago.
- La transferencia por WhatsApp sigue disponible como segunda opción.
